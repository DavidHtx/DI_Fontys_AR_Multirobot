env CPUPROFILE=name.prof env  HEAPPROFILE=name.hprof ./map_merge_node
