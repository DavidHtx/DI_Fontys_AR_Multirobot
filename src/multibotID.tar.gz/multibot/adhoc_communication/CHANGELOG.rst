^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package adhoc_communication
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Fixed CMakeLists error
* Added dynamic naming of robots
* Contributors: Neuhold Daniel, Torsten Andre

0.1.6 (2015-01-08)
------------------
* Removed residual manifest.xml
* Fixed CMAKES errors
* Contributors: Torsten Andre

0.1.5 (2014-12-10)
------------------
* Fixed compilation error map_merger
* Contributors: Torsten Andre

0.1.4 (2014-12-02)
------------------
* Further updates
* Updated adhoc meta information and documentation
* Contributors: Torsten Andre
